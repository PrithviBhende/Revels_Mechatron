"""
MEMORY PATH GAME - LED Floor Game
Dual-lane path memory game for 10x4 LED floor
Uses proven TCP architecture from led_floor_master_WORKING.py

UI Changes:
  - Full window scroll (mousewheel + scrollbar) so all tiles are always visible
  - ESP32 status panel on the right side (piano_tiles style):
      MAC | 🟢 ON / 🔴 OFF | Tiles owned
      Live count label + Reconnect All button
  - Auto-reconnect background thread (restores tile colours after reconnect)
"""

import json
import socket
import tkinter as tk
from tkinter import ttk
import threading
import time
import random
import logging


class MemoryPathGame:
    def __init__(self):
        # Configuration
        self.config_file = 'D:\learning material\college\mechatron\WORKING5\esp_config.json'
        self.esp_port = 8080

        # ESP connections
        self.esp_sockets = {}   # MAC -> socket
        self.esp_status  = {}   # MAC -> 'online' / 'offline'
        self.socket_lock = threading.Lock()

        # Setup logging
        self.setup_logging()

        # Load configuration
        self.load_config()

        # Game state
        self.game_active    = False
        self.preview_running = False

        # Auto-reconnect
        self.reconnect_active   = True   # Lives for the whole app lifetime
        self.reconnect_interval = 5      # Seconds between sweeps
        self.tile_states        = {}     # tile_num -> (r,g,b) or None

        # Player paths
        self.p1_path = []   # 10 values, each 0 or 1
        self.p2_path = []   # 10 values, each 2 or 3

        # Player progress
        self.p1_step = 0
        self.p2_step = 0

        # Colors
        self.color_green = (0, 255, 0)
        self.color_red   = (255, 0, 0)
        self.color_black = (0, 0, 0)

        # Grid layout - 10 rows top to bottom, 4 columns
        self.grid_layout = [
            [37, 38, 39, 40],  # Row 0 - TOP
            [33, 34, 35, 36],
            [29, 30, 31, 32],
            [25, 26, 27, 28],
            [21, 22, 23, 24],
            [17, 18, 19, 20],
            [13, 14, 15, 16],
            [ 9, 10, 11, 12],
            [ 5,  6,  7,  8],
            [ 1,  2,  3,  4],  # Row 9 - BOTTOM
        ]

        self.create_gui()

    # ----------------------------------------------------------------
    #  LOGGING
    # ----------------------------------------------------------------
    def setup_logging(self):
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(message)s',
            handlers=[
                logging.FileHandler('memory_path.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
        self.logger.info("=" * 60)
        self.logger.info("MEMORY PATH GAME - LED FLOOR")
        self.logger.info("=" * 60)

    # ----------------------------------------------------------------
    #  CONFIG
    # ----------------------------------------------------------------
    def load_config(self):
        try:
            with open(self.config_file, 'r') as f:
                config = json.load(f)

            self.grid_rows = config['grid']['rows']
            self.grid_cols = config['grid']['cols']
            self.esp_map   = config['esps']

            self.tile_to_esp = {}
            for mac, tiles in self.esp_map.items():
                for idx, tile_num in enumerate(tiles):
                    self.tile_to_esp[tile_num] = (mac, idx)

            print(f"Loaded config: {self.grid_rows}x{self.grid_cols} grid")
            print(f"{len(self.esp_map)} ESP32 controllers")

            for mac in self.esp_map.keys():
                self.esp_status[mac] = 'offline'

        except FileNotFoundError:
            print(f"Config file not found: {self.config_file}")
            exit(1)
        except Exception as e:
            print(f"Error loading config: {e}")
            exit(1)

    # ----------------------------------------------------------------
    #  CONNECTION
    # ----------------------------------------------------------------
    def connect_to_esp(self, mac):
        try:
            hostname = f"esp-{mac}.local"
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(3)
            sock.connect((hostname, self.esp_port))

            self.logger.info(f"Connected to {mac} ({hostname})")
            self.esp_status[mac] = 'online'

            if hasattr(self, 'root'):
                self.root.after(0, self.update_esp_status_gui)

            return sock

        except socket.gaierror:
            self.logger.error(f"Cannot resolve esp-{mac}.local - check mDNS")
            self.esp_status[mac] = 'offline'
            return None
        except socket.timeout:
            self.logger.error(f"Connection timeout to {mac}")
            self.esp_status[mac] = 'offline'
            return None
        except Exception as e:
            self.logger.error(f"Failed to connect to {mac}: {e}")
            self.esp_status[mac] = 'offline'
            return None

    # ----------------------------------------------------------------
    #  SEND
    # ----------------------------------------------------------------
    def send_command(self, tile_num, command):
        if tile_num not in self.tile_to_esp:
            self.logger.warning(f"Tile {tile_num} not in configuration")
            return False

        mac, local_idx = self.tile_to_esp[tile_num]

        with self.socket_lock:
            if mac not in self.esp_sockets or self.esp_sockets[mac] is None:
                self.esp_sockets[mac] = self.connect_to_esp(mac)

            sock = self.esp_sockets[mac]
            if not sock:
                return False

            try:
                cmd = f"T{local_idx + 1}_{command}\n"
                sock.sendall(cmd.encode())
                return True

            except Exception as e:
                self.logger.error(f"Error sending to {mac}: {e}")
                try:
                    sock.close()
                except Exception:
                    pass
                self.esp_sockets[mac] = None
                self.esp_status[mac] = 'offline'

                if hasattr(self, 'root'):
                    self.root.after(0, self.update_esp_status_gui)

                return False

    def set_tile_color(self, tile_num, color):
        """Set tile colour and record state for reconnect restore."""
        self.tile_states[tile_num] = color if (color and color != (0, 0, 0)) else None

        if color == (0, 0, 0) or color is None:
            command = "OFF"
        else:
            r, g, b = color
            command = f"COLOR_{r}_{g}_{b}"

        return self.send_command(tile_num, command)

    # ----------------------------------------------------------------
    #  AUTO-CONNECT + RECONNECT LOOP
    # ----------------------------------------------------------------
    def auto_connect_esps(self):
        self.logger.info("Connecting to ESPs...")
        time.sleep(1)

        for mac in self.esp_map.keys():
            sock = self.connect_to_esp(mac)
            with self.socket_lock:
                self.esp_sockets[mac] = sock
            time.sleep(0.3)

        connected = sum(1 for s in self.esp_status.values() if s == 'online')
        self.logger.info(f"Connected to {connected}/{len(self.esp_map)} ESPs")
        self.root.after(0, self.update_esp_status_gui)

        # Start background reconnect monitor
        threading.Thread(target=self._reconnect_loop, daemon=True).start()

    def _reconnect_loop(self):
        """
        Silently checks for offline ESPs every reconnect_interval seconds.
        On successful reconnect, restores the tile colours for that ESP.
        Never blocks the game thread.
        """
        while self.reconnect_active:
            time.sleep(self.reconnect_interval)

            for mac in list(self.esp_map.keys()):
                if self.esp_status.get(mac) == 'online':
                    continue

                self.logger.info(f"Auto-reconnect: attempting {mac}...")
                new_sock = self.connect_to_esp(mac)

                if new_sock:
                    with self.socket_lock:
                        self.esp_sockets[mac] = new_sock

                    self.logger.info(f"Reconnected {mac} - restoring tile colours")
                    self._restore_tiles_for_esp(mac)
                    self.root.after(0, self.update_esp_status_gui)

    def _restore_tiles_for_esp(self, mac):
        """Re-send the last known colour for every tile on a freshly reconnected ESP."""
        for tile_num in self.esp_map.get(mac, []):
            color = self.tile_states.get(tile_num)
            if color and color != (0, 0, 0):
                cmd = f"COLOR_{color[0]}_{color[1]}_{color[2]}"
            else:
                cmd = "OFF"

            mac2, local_idx = self.tile_to_esp[tile_num]
            with self.socket_lock:
                sock = self.esp_sockets.get(mac2)
                if not sock:
                    continue
                try:
                    sock.sendall(f"T{local_idx + 1}_{cmd}\n".encode())
                except Exception as e:
                    self.logger.error(f"Restore send error tile {tile_num}: {e}")

            time.sleep(0.05)

    def reconnect_all(self):
        """Manual Reconnect All - closes every socket and reconnects from scratch."""
        def _do():
            self.logger.info("Manual reconnect to all ESPs...")
            with self.socket_lock:
                for sock in self.esp_sockets.values():
                    if sock:
                        try:
                            sock.close()
                        except Exception:
                            pass
                self.esp_sockets.clear()

            for mac in self.esp_map.keys():
                new_sock = self.connect_to_esp(mac)
                with self.socket_lock:
                    self.esp_sockets[mac] = new_sock
                time.sleep(0.3)

            self.root.after(0, self.update_esp_status_gui)

        threading.Thread(target=_do, daemon=True).start()

    # ----------------------------------------------------------------
    #  GUI - MAIN STRUCTURE
    # ----------------------------------------------------------------
    def create_gui(self):
        self.root = tk.Tk()
        self.root.title("Memory Path Game - LED Floor")
        self.root.geometry("1600x950")
        self.root.configure(bg='#1e1e1e')

        # Outer frame fills the window
        outer = tk.Frame(self.root, bg='#1e1e1e')
        outer.pack(fill=tk.BOTH, expand=True)

        # RIGHT panel - ESP status (fixed width, does NOT scroll)
        right_panel = tk.Frame(outer, bg='#2e2e2e', relief=tk.RAISED, bd=2, width=290)
        right_panel.pack(side=tk.RIGHT, fill=tk.Y, padx=(6, 8), pady=8)
        right_panel.pack_propagate(False)
        self.create_esp_panel(right_panel)

        # LEFT side: scrollable canvas containing all game content
        left_side = tk.Frame(outer, bg='#1e1e1e')
        left_side.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(8, 0), pady=8)

        # Vertical scrollbar
        v_scroll = tk.Scrollbar(left_side, orient=tk.VERTICAL)
        v_scroll.pack(side=tk.RIGHT, fill=tk.Y)

        self.main_canvas = tk.Canvas(
            left_side,
            bg='#1e1e1e',
            highlightthickness=0,
            yscrollcommand=v_scroll.set
        )
        self.main_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        v_scroll.config(command=self.main_canvas.yview)

        # Scrollable interior frame
        self.scroll_frame = tk.Frame(self.main_canvas, bg='#1e1e1e')
        self._canvas_window = self.main_canvas.create_window(
            (0, 0), window=self.scroll_frame, anchor='nw'
        )

        # Keep scroll region updated
        self.scroll_frame.bind('<Configure>', self._on_frame_configure)
        self.main_canvas.bind('<Configure>', self._on_canvas_configure)

        # Mousewheel scrolling - Windows/macOS and Linux
        self.root.bind_all('<MouseWheel>', self._on_mousewheel)
        self.root.bind_all('<Button-4>',   self._on_mousewheel_linux)
        self.root.bind_all('<Button-5>',   self._on_mousewheel_linux)

        # Build all content inside scroll_frame
        self._build_scrollable_content(self.scroll_frame)

        # Start ESP connections
        threading.Thread(target=self.auto_connect_esps, daemon=True).start()

    def _on_frame_configure(self, event=None):
        self.main_canvas.configure(scrollregion=self.main_canvas.bbox('all'))

    def _on_canvas_configure(self, event):
        # Stretch the interior frame to match canvas width
        self.main_canvas.itemconfig(self._canvas_window, width=event.width)

    def _on_mousewheel(self, event):
        # Windows: delta=+/-120   macOS: delta=+/-1
        self.main_canvas.yview_scroll(int(-1 * (event.delta / 120)), 'units')

    def _on_mousewheel_linux(self, event):
        if event.num == 4:
            self.main_canvas.yview_scroll(-1, 'units')
        elif event.num == 5:
            self.main_canvas.yview_scroll(1, 'units')

    # ----------------------------------------------------------------
    #  SCROLLABLE CONTENT  (title + grid + controls + status bar)
    # ----------------------------------------------------------------
    def _build_scrollable_content(self, parent):
        # Title
        tk.Label(
            parent,
            text="MEMORY PATH GAME",
            bg='#1e1e1e', fg='#00ff00',
            font=('Arial', 28, 'bold')
        ).pack(pady=(10, 6))

        # Main row: grid on left, controls on right
        center = tk.Frame(parent, bg='#1e1e1e')
        center.pack(fill=tk.BOTH, expand=True, pady=(0, 6))

        grid_col = tk.Frame(center, bg='#1e1e1e')
        grid_col.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 8))

        ctrl_col = tk.Frame(center, bg='#2e2e2e', relief=tk.RAISED, bd=2)
        ctrl_col.pack(side=tk.LEFT, fill=tk.Y)

        self.create_virtual_grid(grid_col)
        self.create_control_panel(ctrl_col)

        # Status bar at the bottom
        self.create_status_bar(parent)

    # ----------------------------------------------------------------
    #  VIRTUAL GRID  (all 10 rows always visible)
    # ----------------------------------------------------------------
    def create_virtual_grid(self, parent):
        grid_frame = tk.LabelFrame(
            parent,
            text="LED Floor Grid  (10 rows x 4 columns  |  Top to Bottom)",
            bg='#2e2e2e', fg='white',
            font=('Arial', 13, 'bold'),
            padx=12, pady=12
        )
        grid_frame.pack(fill=tk.BOTH, expand=True)

        # Lane header labels
        header = tk.Frame(grid_frame, bg='#2e2e2e')
        header.pack(fill=tk.X, pady=(0, 8))

        tk.Label(
            header, text="  PLAYER 1 LANE  ",
            bg='#1a3a5c', fg='#00aaff',
            font=('Arial', 11, 'bold'),
            relief=tk.GROOVE, bd=2, padx=8, pady=4
        ).pack(side=tk.LEFT, expand=True, fill=tk.X, padx=(0, 4))

        tk.Label(
            header, text="  PLAYER 2 LANE  ",
            bg='#5c1a3a', fg='#ff00aa',
            font=('Arial', 11, 'bold'),
            relief=tk.GROOVE, bd=2, padx=8, pady=4
        ).pack(side=tk.LEFT, expand=True, fill=tk.X, padx=(4, 0))

        # Tile grid with row labels
        tiles_frame = tk.Frame(grid_frame, bg='#2e2e2e')
        tiles_frame.pack()

        self.tile_labels = {}

        for row_idx in range(10):
            # Row label
            tk.Label(
                tiles_frame,
                text=f"R{row_idx}",
                bg='#2e2e2e', fg='#888888',
                font=('Arial', 8), width=3
            ).grid(row=row_idx, column=0, padx=(0, 4))

            for col_idx in range(4):
                tile_num = self.grid_layout[row_idx][col_idx]
                border   = '#00aaff' if col_idx < 2 else '#ff00aa'

                tile = tk.Label(
                    tiles_frame,
                    text=str(tile_num),
                    width=11, height=3,
                    bg='#000000', fg='#555555',
                    font=('Arial', 11, 'bold'),
                    relief=tk.RAISED, bd=3,
                    highlightthickness=2,
                    highlightbackground=border
                )
                tile.grid(row=row_idx, column=col_idx + 1, padx=4, pady=3)
                self.tile_labels[tile_num] = tile

        # Column index labels at the bottom
        for col_idx in range(4):
            tk.Label(
                tiles_frame,
                text=f"C{col_idx}",
                bg='#2e2e2e', fg='#888888',
                font=('Arial', 8)
            ).grid(row=10, column=col_idx + 1, pady=(4, 0))

    # ----------------------------------------------------------------
    #  CONTROL PANEL  (beside grid, inside scrollable area)
    # ----------------------------------------------------------------
    def create_control_panel(self, parent):
        tk.Label(
            parent,
            text="GAME CONTROLS",
            bg='#2e2e2e', fg='white',
            font=('Arial', 15, 'bold')
        ).pack(pady=14)

        # Game Setup
        setup_f = tk.LabelFrame(
            parent, text="Game Setup",
            bg='#2e2e2e', fg='white',
            font=('Arial', 10, 'bold'), padx=10, pady=10
        )
        setup_f.pack(fill=tk.X, padx=10, pady=5)

        tk.Button(
            setup_f, text="FULL RESET\nGenerate New Paths",
            command=self.full_reset,
            bg='#ff6600', fg='white',
            font=('Arial', 11, 'bold'), height=3, width=22
        ).pack(pady=5)

        tk.Button(
            setup_f, text="START PREVIEW\nShow Paths",
            command=self.start_preview,
            bg='#0066ff', fg='white',
            font=('Arial', 11, 'bold'), height=3, width=22
        ).pack(pady=5)

        # Gameplay
        game_f = tk.LabelFrame(
            parent, text="Gameplay",
            bg='#2e2e2e', fg='white',
            font=('Arial', 10, 'bold'), padx=10, pady=10
        )
        game_f.pack(fill=tk.X, padx=10, pady=5)

        tk.Button(
            game_f, text="NEXT STEP",
            command=self.next_step,
            bg='#00cc00', fg='white',
            font=('Arial', 15, 'bold'), height=4, width=22
        ).pack(pady=8)

        # Player Resets
        pr_f = tk.LabelFrame(
            parent, text="Player Resets",
            bg='#2e2e2e', fg='white',
            font=('Arial', 10, 'bold'), padx=10, pady=10
        )
        pr_f.pack(fill=tk.X, padx=10, pady=5)

        tk.Button(
            pr_f, text="Reset Player 1",
            command=self.reset_player1,
            bg='#00aaff', fg='white',
            font=('Arial', 10, 'bold'), height=2, width=22
        ).pack(pady=4)

        tk.Button(
            pr_f, text="Reset Player 2",
            command=self.reset_player2,
            bg='#ff00aa', fg='white',
            font=('Arial', 10, 'bold'), height=2, width=22
        ).pack(pady=4)

        # Game Status
        gs_f = tk.LabelFrame(
            parent, text="Game Status",
            bg='#2e2e2e', fg='white',
            font=('Arial', 10, 'bold'), padx=10, pady=10
        )
        gs_f.pack(fill=tk.X, padx=10, pady=5)

        self.p1_status_label = tk.Label(
            gs_f, text="Player 1: Row 0 / 10",
            bg='#2e2e2e', fg='#00aaff',
            font=('Arial', 10, 'bold'), anchor='w'
        )
        self.p1_status_label.pack(fill=tk.X, pady=2)

        self.p2_status_label = tk.Label(
            gs_f, text="Player 2: Row 0 / 10",
            bg='#2e2e2e', fg='#ff00aa',
            font=('Arial', 10, 'bold'), anchor='w'
        )
        self.p2_status_label.pack(fill=tk.X, pady=2)

        # Legend
        legend_f = tk.LabelFrame(
            parent, text="Legend",
            bg='#2e2e2e', fg='white',
            font=('Arial', 10, 'bold'), padx=10, pady=8
        )
        legend_f.pack(fill=tk.X, padx=10, pady=5)

        for text, color in [
            ("  Correct path", '#00ff00'),
            ("  Wrong tile",   '#ff0000'),
            ("  Off / cleared",'#555555'),
        ]:
            tk.Label(
                legend_f, text=text,
                bg='#2e2e2e', fg=color,
                font=('Arial', 9, 'bold'), anchor='w'
            ).pack(fill=tk.X, pady=1)

    # ----------------------------------------------------------------
    #  ESP STATUS PANEL  (right side, fixed - does NOT scroll)
    #  Styled after piano_tiles_working.py
    # ----------------------------------------------------------------
    def create_esp_panel(self, parent):
        tk.Label(
            parent,
            text="ESP32 STATUS",
            bg='#2e2e2e', fg='#00ff00',
            font=('Arial', 14, 'bold')
        ).pack(pady=12)

        # Summary count
        self.esp_count_label = tk.Label(
            parent,
            text="0 / 0 online",
            bg='#2e2e2e', fg='white',
            font=('Arial', 11)
        )
        self.esp_count_label.pack(pady=(0, 6))

        # Scrollable list of ESP rows
        list_frame = tk.LabelFrame(
            parent, text="Controllers",
            bg='#2e2e2e', fg='white',
            font=('Arial', 9, 'bold'), padx=6, pady=6
        )
        list_frame.pack(fill=tk.BOTH, expand=True, padx=8, pady=4)

        esp_canvas = tk.Canvas(list_frame, bg='#2e2e2e', highlightthickness=0)
        esp_scroll = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=esp_canvas.yview)
        self.esp_status_frame = tk.Frame(esp_canvas, bg='#2e2e2e')

        esp_canvas.configure(yscrollcommand=esp_scroll.set)
        esp_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        esp_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        esp_canvas.create_window((0, 0), window=self.esp_status_frame, anchor='nw')

        self.esp_status_frame.bind(
            '<Configure>',
            lambda e: esp_canvas.configure(scrollregion=esp_canvas.bbox('all'))
        )

        # Auto-reconnect status line
        self.reconnect_status_label = tk.Label(
            parent,
            text="Auto-reconnect: active",
            bg='#2e2e2e', fg='#888888',
            font=('Arial', 8)
        )
        self.reconnect_status_label.pack(pady=(6, 2))

        # Manual reconnect button
        tk.Button(
            parent,
            text="Reconnect All ESPs",
            command=self.reconnect_all,
            bg='#5bc0de', fg='white',
            font=('Arial', 9, 'bold'), width=22
        ).pack(padx=8, pady=6)

    def update_esp_status_gui(self):
        """Rebuild the ESP status rows - piano_tiles style."""
        # Clear old rows
        for w in self.esp_status_frame.winfo_children():
            w.destroy()

        online_count = 0
        for mac, tiles in self.esp_map.items():
            status = self.esp_status.get(mac, 'offline')
            if status == 'online':
                online_count += 1

            row = tk.Frame(self.esp_status_frame, bg='#3e3e3e', relief=tk.RAISED, bd=1)
            row.pack(fill=tk.X, pady=2, padx=2)

            # Short MAC address
            tk.Label(
                row, text=mac[-6:],
                bg='#3e3e3e', fg='white',
                font=('Arial', 9, 'bold'), width=8, anchor='w'
            ).pack(side=tk.LEFT, padx=4)

            # Status badge with coloured background (piano-tiles style)
            badge_text  = "ON"  if status == 'online' else "OFF"
            badge_color = '#5cb85c' if status == 'online' else '#d9534f'
            tk.Label(
                row, text=badge_text,
                bg=badge_color, fg='white',
                font=('Arial', 8, 'bold'), width=5
            ).pack(side=tk.LEFT, padx=4)

            # Tiles list
            tk.Label(
                row, text=f"Tiles: {tiles}",
                bg='#3e3e3e', fg='#cccccc',
                font=('Arial', 7), anchor='w'
            ).pack(side=tk.LEFT, padx=4, fill=tk.X, expand=True)

        # Summary count with colour feedback
        total = len(self.esp_map)
        if online_count == total:
            count_color = '#00ff00'
        elif online_count > 0:
            count_color = '#ffaa00'
        else:
            count_color = '#ff4444'

        self.esp_count_label.config(
            text=f"{online_count} / {total} online",
            fg=count_color
        )

        # Reconnect status line
        offline_macs = [m for m, s in self.esp_status.items() if s == 'offline']
        if offline_macs:
            self.reconnect_status_label.config(
                text=f"Reconnecting: {', '.join(m[-6:] for m in offline_macs[:2])}...",
                fg='#ffaa00'
            )
        else:
            self.reconnect_status_label.config(
                text="Auto-reconnect: all online",
                fg='#00aa00'
            )

        # Update status bar (only when not mid-game)
        if hasattr(self, 'status_label') and not self.preview_running and not self.game_active:
            if online_count == total:
                self.status_label.config(text=f"All {total} ESPs connected")
            else:
                self.status_label.config(text=f"{online_count}/{total} ESPs connected")

    # ----------------------------------------------------------------
    #  STATUS BAR  (bottom of scroll area)
    # ----------------------------------------------------------------
    def create_status_bar(self, parent):
        status_frame = tk.Frame(parent, bg='#2e2e2e', relief=tk.SUNKEN, bd=2)
        status_frame.pack(fill=tk.X, pady=(8, 0))

        self.status_label = tk.Label(
            status_frame,
            text="Ready - press Full Reset to start",
            bg='#2e2e2e', fg='white',
            font=('Arial', 11),
            anchor='w', padx=10, pady=5
        )
        self.status_label.pack(fill=tk.X)

    # ----------------------------------------------------------------
    #  HELPERS
    # ----------------------------------------------------------------
    def update_virtual_grid(self):
        for label in self.tile_labels.values():
            label.config(bg='#000000', fg='#555555')

    def update_status_display(self):
        self.p1_status_label.config(text=f"Player 1: Row {self.p1_step} / 10")
        self.p2_status_label.config(text=f"Player 2: Row {self.p2_step} / 10")

    def _rgb_to_hex(self, rgb):
        return "#{:02x}{:02x}{:02x}".format(*rgb)

    def _update_tile_gui(self, tile1, color1, tile2, color2):
        if tile1 in self.tile_labels:
            self.tile_labels[tile1].config(bg=self._rgb_to_hex(color1))
        if tile2 in self.tile_labels:
            self.tile_labels[tile2].config(bg=self._rgb_to_hex(color2))

    # ----------------------------------------------------------------
    #  GAME LOGIC
    # ----------------------------------------------------------------
    def full_reset(self):
        self.logger.info("Full Reset - generating new paths")

        self.p1_step = 0
        self.p2_step = 0

        self.p1_path = [random.randint(0, 1) for _ in range(10)]
        self.p2_path = [random.randint(2, 3) for _ in range(10)]

        self.logger.info(f"P1 path: {self.p1_path}")
        self.logger.info(f"P2 path: {self.p2_path}")

        self.clear_floor()
        self.update_status_display()
        self.status_label.config(text="New paths generated! Press Start Preview to see them.")

    def start_preview(self):
        if self.preview_running:
            self.logger.warning("Preview already running")
            return
        if not self.p1_path or not self.p2_path:
            self.status_label.config(text="No paths! Press Full Reset first.")
            return
        threading.Thread(target=self._run_preview, daemon=True).start()

    def _run_preview(self):
        self.preview_running = True
        self.root.after(0, lambda: self.status_label.config(text="Preview starting..."))
        time.sleep(0.5)

        for row_idx in range(10):
            p1_col  = self.p1_path[row_idx]
            p2_col  = self.p2_path[row_idx]
            p1_tile = self.grid_layout[row_idx][p1_col]
            p2_tile = self.grid_layout[row_idx][p2_col]

            self.set_tile_color(p1_tile, self.color_green)
            self.set_tile_color(p2_tile, self.color_green)

            self.root.after(0, lambda t1=p1_tile, t2=p2_tile:
                self._update_tile_gui(t1, self.color_green, t2, self.color_green))

            time.sleep(0.3)

        self.root.after(0, lambda: self.status_label.config(text="Memorize the path!"))
        time.sleep(2)

        self.root.after(0, lambda: self.status_label.config(text="Floor cleared - Ready to play!"))
        self.clear_floor()
        self.preview_running = False

    def next_step(self):
        if self.preview_running:
            self.logger.warning("Wait for preview to finish")
            return
        if not self.p1_path or not self.p2_path:
            self.status_label.config(text="No paths! Press Full Reset first.")
            return

        # Clear previous row
        if self.p1_step > 0:
            for col in [0, 1]:
                tile = self.grid_layout[self.p1_step - 1][col]
                self.set_tile_color(tile, self.color_black)
                self.root.after(0, lambda t=tile: self.tile_labels[t].config(bg='#000000'))

        if self.p2_step > 0:
            for col in [2, 3]:
                tile = self.grid_layout[self.p2_step - 1][col]
                self.set_tile_color(tile, self.color_black)
                self.root.after(0, lambda t=tile: self.tile_labels[t].config(bg='#000000'))

        time.sleep(0.1)

        # Player 1
        if self.p1_step < 10:
            row_idx       = self.p1_step
            correct_col   = self.p1_path[row_idx]
            incorrect_col = 1 - correct_col
            correct_tile   = self.grid_layout[row_idx][correct_col]
            incorrect_tile = self.grid_layout[row_idx][incorrect_col]

            self.set_tile_color(correct_tile,   self.color_green)
            self.set_tile_color(incorrect_tile, self.color_red)

            self.root.after(0, lambda ct=correct_tile, it=incorrect_tile: (
                self.tile_labels[ct].config(bg=self._rgb_to_hex(self.color_green)),
                self.tile_labels[it].config(bg=self._rgb_to_hex(self.color_red))
            ))
            self.p1_step += 1

        # Player 2
        if self.p2_step < 10:
            row_idx       = self.p2_step
            correct_col   = self.p2_path[row_idx]
            incorrect_col = 5 - correct_col
            correct_tile   = self.grid_layout[row_idx][correct_col]
            incorrect_tile = self.grid_layout[row_idx][incorrect_col]

            self.set_tile_color(correct_tile,   self.color_green)
            self.set_tile_color(incorrect_tile, self.color_red)

            self.root.after(0, lambda ct=correct_tile, it=incorrect_tile: (
                self.tile_labels[ct].config(bg=self._rgb_to_hex(self.color_green)),
                self.tile_labels[it].config(bg=self._rgb_to_hex(self.color_red))
            ))
            self.p2_step += 1

        self.update_status_display()

        if self.p1_step >= 10 and self.p2_step >= 10:
            self.status_label.config(text="Game Complete! Both players finished!")
        else:
            self.status_label.config(text=f"Step:  P1 = {self.p1_step}/10     P2 = {self.p2_step}/10")

    def reset_player1(self):
        self.logger.info("Resetting Player 1")
        for row_idx in range(10):
            for col in [0, 1]:
                tile = self.grid_layout[row_idx][col]
                self.set_tile_color(tile, self.color_black)
                self.root.after(0, lambda t=tile: self.tile_labels[t].config(bg='#000000'))
        self.p1_step = 0
        self.update_status_display()
        self.status_label.config(text="Player 1 reset to Row 0")

    def reset_player2(self):
        self.logger.info("Resetting Player 2")
        for row_idx in range(10):
            for col in [2, 3]:
                tile = self.grid_layout[row_idx][col]
                self.set_tile_color(tile, self.color_black)
                self.root.after(0, lambda t=tile: self.tile_labels[t].config(bg='#000000'))
        self.p2_step = 0
        self.update_status_display()
        self.status_label.config(text="Player 2 reset to Row 0")

    def clear_floor(self):
        for row in self.grid_layout:
            for tile_num in row:
                self.set_tile_color(tile_num, self.color_black)
        self.root.after(0, self.update_virtual_grid)

    # ----------------------------------------------------------------
    #  RUN
    # ----------------------------------------------------------------
    def run(self):
        try:
            self.root.mainloop()
        finally:
            self.reconnect_active = False
            with self.socket_lock:
                for sock in self.esp_sockets.values():
                    if sock:
                        try:
                            sock.close()
                        except Exception:
                            pass


# ────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("=" * 60)
    print("MEMORY PATH GAME - LED FLOOR")
    print("=" * 60)
    print()
    print("Game Rules:")
    print("- Two players, each with their own lane (2 columns)")
    print("- Each lane has a random path of correct tiles")
    print("- Preview shows the full path in green")
    print("- During play, green = correct, red = incorrect")
    print("- Players must remember the path!")
    print("=" * 60)
    print()

    game = MemoryPathGame()
    game.run()
